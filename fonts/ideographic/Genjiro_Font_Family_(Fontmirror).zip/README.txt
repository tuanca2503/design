To learn more about the font family and its license, visit https://www.fontmirror.com/genjiro

License: Free for personal use.
This is a preview font for testing, you can purchase its full version at https://crmrkt.com/dQez0J.Contact hello.rometheme@gmail.com for commercial use.
You can donate to the font author at http://paypal.me/YahdiKumala.
To learn more about the font, visit https://rometheme.net/product/genjiro-japanese-font/.